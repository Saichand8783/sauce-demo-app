# Sample code for checkout.py

