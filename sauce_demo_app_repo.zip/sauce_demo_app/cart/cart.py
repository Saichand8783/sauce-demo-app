# Sample code for cart.py

